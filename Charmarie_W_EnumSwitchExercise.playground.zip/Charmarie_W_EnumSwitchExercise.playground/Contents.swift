import UIKit

enum SandwichTypes {
    case ham
    case cheese
    case turkey
}

var sandwichOptions = SandwichTypes.cheese

switch sandwichOptions {

case .ham:
    print("ham, cheese, relish")
case .cheese:
    print("beef, cheese, ketchup")
case .turkey:
    print("turkey, bacon, mustard")
}
